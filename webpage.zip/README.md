
  # One Page Digital Solutions Site

  This is a code bundle for One Page Digital Solutions Site. The original project is available at https://www.figma.com/design/GhJiSyBuZDIfLtSzLl3ki0/One-Page-Digital-Solutions-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  